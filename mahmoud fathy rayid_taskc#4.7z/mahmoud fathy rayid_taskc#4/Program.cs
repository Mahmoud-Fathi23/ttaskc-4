﻿using System;

namespace ConsoleApp37
{
    //enum DaysOfWeek
    //{
    //    Sunday = 1,
    //    Monday,
    //    Tuesday,
    //    Wednesday,
    //    Thursday,
    //    Friday,
    //    Saturday
    //}
    internal class Program
    {
        static void Main(string[] args)
        {
            #region part1
            //int[] num = new int[4] { 1, 2, 3,4 };
            //int[] num1=new int[] {5,6,7,8,9,10,11,12};
            //int[] num2 = { 0, 1, 2, 3,4 };

            //Console.WriteLine(num.Length);
            //Console.WriteLine(num1.Length);
            //Console.WriteLine(num2.Length);

            //foreach (int i in num)
            //{
            //    Console.WriteLine(i);
            //}

            //Console.WriteLine();

            //foreach (int i in num1)
            //{
            //    Console.WriteLine(i);
            //}
            //Console.WriteLine();

            //foreach (int i in num2)
            //{
            //    Console.WriteLine(i);
            //}

            //for (int i = 0; i < num.Length; i++)
            //{
            //    Console.WriteLine(num[i]);
            //}
            //Console.WriteLine();
            //for (int i = 0; i < num1.Length; i++)
            //{
            //    Console.WriteLine(num1[i]);
            //}
            //Console.WriteLine();
            //for (int i = 0; i < num2.Length; i++)
            //{
            //    Console.WriteLine(num2[i]);
            //}

            #endregion

            #region part2
            //int[] arr01 = { 1, 2, 3 };
            //int[] arr02 = { 4, 5, 6 };
            //Console.WriteLine(arr01.GetHashCode()); //58225482
            //Console.WriteLine(arr02.GetHashCode()); //54267293
            //arr02 = arr01;
            //Console.WriteLine(arr02.GetHashCode());//58225482

            //arr01[0] = 15;
            //Console.WriteLine(arr02[0]);

            //arr02 = (int[])arr01.Clone();
            //arr01[0] = 6;
            //Console.WriteLine(arr02[0]);
            #endregion

            #region part3
            //int[,] grades =new int[3,3];
            //Console.WriteLine("enter student grades 3 students and 3 subjects");
            ////for(int i = 0; i <= 3; i++)
            //{
            //    Console.WriteLine("enter 3 students (i + 1):");
            //for (int j = 0; j <= 3; j++)
            //{
            //    Console.WriteLine("enter 3 subjects (j + 1):");


            //    while (!int.TryParse(Console.ReadLine(), out grades[i, j]) || grades[i, j] < 0 || grades[i, j] > 100)
            //    {
            //        Console.WriteLine("Invalid grade. Please enter a number between 0 and 100.");
            //        Console.Write("Subject {j + 1}: ");
            //    }
            //}


            //for (int i = 0; i < 3; i++)
            //{
            //    Console.WriteLine("enter 3 students (i + 1):");
            //    for (int j = 0; j < 3; j++)
            //    {
            //        Console.WriteLine("enter 3 subjects (j + 1):");
            //    }

            //}
            //Console.WriteLine();
            #endregion

            #region part4
            //int[] Arr01 = { 9, 3, 10, 2, 8, 10, 6, 5, 1 };
            //int[] Arr02 = { 1, 2, 3 };
            //int[] Arr03 = new int[5];
            //int[] Arr04 = { 8, 5 };
            //int[] Arr05 = { 7, 9, 10 };


            //Array.Sort(Arr01);//1 2 3 5 6 8 9 10 10

            //Array.Reverse(Arr02); //3 2 1

            //Array.Copy(Arr01, Arr02, 2); // 10 2 3

            //Array.Clear(Arr01, 2, 4);//1 2 0000 9 10 10

            //Array.ConstrainedCopy(Arr02, 0, Arr03, 0, 2);//3 2 1 0 0

            //int Index = Array.IndexOf(Arr01, 10);
            //Console.WriteLine(Index);//7
            //Console.WriteLine();

            //int Index2 = Array.LastIndexOf(Arr01, 10);
            //Console.WriteLine(Index2);//8
            //Console.WriteLine();
            #endregion

            #region part5
            //int[] num = { 5, 6, 4, 8, 2, 7, 3, 1, 10 };

            //for(int i = 0; i < num.Length; i++)
            //{
            //    Console.WriteLine(num[i]);
            //}
            //Console.WriteLine();
            //foreach (int i in num)
            //{
            //    Console.WriteLine(num[i]);
            //}

            //int i = 1;
            //while (i < num.Length)
            //{
            //    Console.WriteLine(num[i]);
            //    i++;
            //}
            #endregion

            #region par6
            //int num;
            //bool flag;
            //do
            //{
            //    Console.WriteLine("enter odd number");
            //    flag=int.TryParse(Console.ReadLine(), out num);
            //}
            //while (num %2 == 0 || !flag || num < 0);

            #endregion

            #region part7
            //int[,] matrix =
            //{
            //    {1,2,3 },
            //    {4,5,6 },
            //    {7,8,9 }
            //};
            //for(int i = 0; i < matrix.GetLength(0); i++)
            //{
            //    for(int j = 0; j < matrix.GetLength(1); j++)
            //    {
            //        Console.Write(matrix[i, j] + "\t"); 

            //    }
            //    Console.WriteLine();
            //}
            #endregion

            #region part8
            //Console.Write("Enter month number at first quarter : ");
            //int.TryParse(Console.ReadLine(), out int MonthNumber);
            //if (MonthNumber == 1)
            //    Console.WriteLine("Jan");
            //else if (MonthNumber == 2)
            //    Console.WriteLine("Feb");
            //else if (MonthNumber == 3)
            //    Console.WriteLine("Mar");
            //else
            //    Console.WriteLine("not in first quarter");



            //Console.WriteLine("Enter the month");
            //int.TryParse(Console.ReadLine(), out int MmonthNumber);
            //switch (MonthNumber)
            //{
            //    case 1:
            //        Console.WriteLine("Jan");
            //        break;
            //    case 2:
            //        Console.WriteLine("Feb");
            //        break;
            //    case 3:
            //        Console.WriteLine("Mar");
            //        break;
            //    default:
            //        Console.WriteLine("Not in Q01");
            //        break;
            //}
            #endregion

            #region part2_2
            //Console.Write("Enter a number between 1 and 7 to get the corresponding day of the week: ");
            //int x = int.Parse(Console.ReadLine());

            //if (x >= 1 && x <= 7)
            //{
            //    DaysOfWeek day = (DaysOfWeek)Enum.Parse(typeof(DaysOfWeek), x.ToString());

            //    // Output the corresponding day
            //    Console.WriteLine($"The day corresponding to {x} is {day}.");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid input! Please enter a number between 1 and 7.");
            //}
            /*إذا أدخل المستخدم قيمة خارج النطاق من 1 إلى 7، فإن البرنامج يتعامل مع هذا السيناريو من خلال التحقق من صحة الإدخال قبل محاولة تحويله إلى قيمة في الـ enum*/
            #endregion
        }
    }
}
